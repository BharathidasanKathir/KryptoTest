﻿using HistoricalExchangeRateApi.Models;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Web;

namespace HistoricalExchangeRateApi.Helper
{
    public  class JsonHelper
    {
        public List<Exchange> ConvertExchangeRate (JObject d )
        {
            List<Exchange> objExchanges = new List<Exchange>();
             foreach (dynamic data in d)
                    {
                        if (data.Key == "rates")
                        {
                            var jObj = (JObject)data.Value;

                            foreach (JToken token in jObj.Children())
                            {
                                Exchange newExchange = new Exchange();
                                if (token is JProperty)
                                {
                                    var prop = token as JProperty;
                                    newExchange.ExchangeDate = DateTime.ParseExact(prop.Name, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                                    var newObj = (JObject)prop.Value;
                                            foreach (JToken nextToken in newObj.Children())
                                            {
                                                if (token is JProperty)
                                                {
                                                    var prop1 = nextToken as JProperty;
                                                    newExchange.ExchangeRate = decimal.Parse(prop1.Value.ToString());
                                                }
                                            }
                                }
                        objExchanges.Add(newExchange);

                             }
                        }
                    }
            return objExchanges;
        }
    }
}