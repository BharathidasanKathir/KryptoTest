﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HistoricalExchangeRateApi.Models
{
    public class Exchange
    {
        public DateTime ExchangeDate { get; set; }
        public decimal ExchangeRate { get; set; }
    }
}